# 🎓 Restuding

> *Aventura indie de múltiplos finais*

Um jogo pixel art sobre o poder do ensino. Controle o professor, pegue o item **ENSINAR** e transmita conhecimento para o aluno!

![Cenário](assets/sala_aula.png)

## 🚀 Jogue Agora

🔗 **[Clique aqui para jogar](https://SEU-USUARIO.github.io/restuding/)**

*(Substitua `SEU-USUARIO` pelo seu nome de usuário do GitHub após publicar)*

## 🎮 Controles

| Ação | Teclado | Mobile |
|------|---------|--------|
| Andar | `←` `→` ou `A` `D` | Botões ◀ ▶ |
| Pular | `Espaço` ou `W` `↑` | Botão **PULAR** |
| Interagir | `E` ou `Enter` | Botão **INTERAGIR** |

## 📁 Estrutura do Projeto

```
restuding/
├── index.html              # Página principal
├── css/
│   └── style.css           # Estilos e controles mobile
├── js/
│   └── game.js             # Lógica do jogo completa
├── assets/
│   ├── sala_aula.png       # Cenário da sala de aula
│   ├── teacher.jpg         # Sprite do professor
│   ├── teacherWithItem.png # Professor com item
│   └── teachItem.png       # Item "ENSINAR"
└── README.md               # Este arquivo
```

## 🛠️ Como Publicar no GitHub Pages

### 1. Crie um novo repositório
- Acesse [github.com/new](https://github.com/new)
- Nome: `restuding`
- Deixe público ✅
- Clique em **Create repository**

### 2. Envie os arquivos

#### Opção A: Upload direto (mais fácil)
1. Na página do repositório, clique em **"Add file" → "Upload files"**
2. Arraste todos os arquivos e pastas (`index.html`, `css/`, `js/`, `assets/`)
3. Clique em **"Commit changes"**

#### Opção B: Git (para desenvolvedores)
```bash
git clone https://github.com/SEU-USUARIO/restuding.git
cd restuding
# Copie os arquivos do jogo para esta pasta
git add .
git commit -m "Primeira versão do Restuding"
git push origin main
```

### 3. Ative o GitHub Pages
1. No repositório, vá em **Settings** ⚙️
2. No menu lateral, clique em **Pages**
3. Em **Source**, selecione: **Deploy from a branch**
4. Selecione a branch `main` e pasta `/ (root)`
5. Clique em **Save**
6. Aguarde 1-2 minutos e acesse o link gerado!

## 🎯 Objetivo do Jogo

1. **Ande** até o item dourado perto do quadro
2. **Pegue** o item **ENSINAR** pressionando `E`
3. **Aproxime-se** do aluno à esquerda
4. **Use** o poder de ensinar pressionando `E`
5. **Desbloqueie** o Final 1: *「O Primeiro Ensinamento」*

## 🖼️ Sobre o Cenário

O cenário da **Sala de Aula** apresenta:
- 📋 Quadro negro (esquerda)
- 🟩 Quadro verde / lousa (direita) — onde aparecem os diálogos
- 📚 Prateleira com giz
- 🪑 Ambiente escolar completo

## 📝 Licença

Este é um projeto indie educativo. Sinta-se livre para modificar e expandir!

---

**Desenvolvido com 💛 e JavaScript puro**
